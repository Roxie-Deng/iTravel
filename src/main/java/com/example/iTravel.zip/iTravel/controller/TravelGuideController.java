package com.example.iTravel.controller;

import com.example.iTravel.model.TravelGuide;
import com.example.iTravel.service.TravelGuideService;
import io.jsonwebtoken.Claims;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping("/api/guides")
@CrossOrigin(origins = "http://localhost:3000")
public class TravelGuideController {

    @Autowired
    private TravelGuideService travelGuideService;

    @PostMapping("/guide")
    public ResponseEntity<?> saveGuide(@RequestBody TravelGuide guide, HttpServletRequest request) {
        Claims claims = (Claims) request.getAttribute("claims");
        if (claims == null) {
            return ResponseEntity.status(401).body("User is not authenticated");
        }
        String userId = claims.getSubject();
        guide.setUserId(userId);
        TravelGuide savedGuide = travelGuideService.saveTravelGuide(guide);
        return ResponseEntity.ok(savedGuide);
    }

    @GetMapping("/user/{userId}")
    public List<TravelGuide> getGuidesByUserId(@PathVariable String userId) {
        return travelGuideService.getGuidesByUserId(userId);
    }
}