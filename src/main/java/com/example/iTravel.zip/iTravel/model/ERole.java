package com.example.iTravel.model;

public enum ERole {
    ROLE_USER,
    ROLE_ADMIN
}